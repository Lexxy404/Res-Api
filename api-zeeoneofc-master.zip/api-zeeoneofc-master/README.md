
 
# Source Codes - Zhirrr's API
<p align="center">
<a href="#"><img title="api zeeoneofc" src="https://img.shields.io/badge/zeeoneofc Api-blue?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/zeeoneofc"><img title="Author" src="https://img.shields.io/badge/Author-Zhirrr-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/zeeoneofc/followers"><img title="Followers" src="https://img.shields.io/github/followers/zeeoneofc?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/api-zeeoneofc/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/zeeoneofc/api-zeeoneofc?color=blue&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/api-zeeoneofc/network/members"><img title="Forks" src="https://img.shields.io/github/forks/zeeoneofc/api-zeeoneofc?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/api-zeeoneofc/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/zeeoneofc/api-zeeoneofc?label=Watchers&color=blue&style=flat-square"></a>
</p>
<p align='center'>
   <a href="https://wa.me/message/SJGWPAW7OHHXK1"><img height="30" src="https://c.top4top.io/p_1837yybbf0.jpeg"></a>&nbsp;&nbsp;
   <a href="https://instagram.com/zeeoneofc"><img height="30" src="https://raw.githubusercontent.com/TobyG74/TobyG74/main/instagram.jpg"></a>
</P>

## Api Features
Check it yourself [Here](https://api-zeeoneofc.herokuapp.com)


## Cara Ganti ApiKey Gimana?
Cara Mengganti Nya Cukup Gampang, Kalian Hanya Perlu Untuk Mengganti Syntax Di Bawah Ini
```js
if(apikeyInput != 'MASUKKAN_NAMA_APIKEY') return res.json(loghandler.invalidKey)
```
Atau

```js
if(apikey != 'MASUKAN_NAMA_APIKEY') return res.json(loghandler.invalidKey)
```
<h1 align="center"> Cara Deploy Ada Di YouTube Saya
<p align="center">
  <a href="https://youtu.be/TyNPsf_x0qE"><img src="https://img.shields.io/badge/-Youtube-red?style=flat-square&logo=youtube" /> <br>
  
</p>


# Special Thanks
- Zhirrr
- ZefianAlfian (Makasih template nya)
- sProDev (Makasih Kodeposnya)
- devnazir (Credits : FilmApik, LK21)
